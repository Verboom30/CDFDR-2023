All Mechaduino related materials are released under the

Creative Commons Attribution Share-Alike 4.0 License

https://creativecommons.org/licenses/by-sa/4.0/
